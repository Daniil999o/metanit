export function createItem(name, description, price, img) {
    const item = document.createElement('div');
    item.classList.add('card');
    item.style.width = '18rem';

    const cardImg = document.createElement('img');
    cardImg.classList.add('card-img-top');

    const cardBody = document.createElement('div');
    cardBody.classList.add('card-body');

    const cardName = document.createElement('h5');
    cardName.classList.add('card-title');

    const cardDescription = document.createElement('p');
    cardDescription.classList.add('card-text');

    const cardPrice = document.createElement('p');
    cardPrice.classList.add('card-text');

    const editBtn = document.createElement('a');
    editBtn.classList.add('btn', 'btn-primary');
    editBtn.textContent = 'More';

    const deleteBtn = document.createElement('a');
    deleteBtn.classList.add('btn', 'btn-primary');
    deleteBtn.style.backgroundColor = 'red';
    deleteBtn.textContent = 'Delete';
    
    cardName.textContent = name;
    cardDescription.textContent = description;
    cardPrice.innerHTML = `Price: <b>$${price}</b>`;
    cardImg.src = img;

    cardBody.append(cardName, cardDescription, cardPrice, editBtn, deleteBtn);
    item.append(cardImg, cardBody);

    return {item, editBtn, deleteBtn};
}