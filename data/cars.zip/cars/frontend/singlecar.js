import { getOneCar, updateCar } from "../requests/car.requests.js";

let carId = window.location.pathname.split('/').pop();

document.addEventListener('DOMContentLoaded', async ()=>{
    document.getElementById('saveBtn').addEventListener('click', async (e)=>{
        e.preventDefault();

        await updateThisCar();
    });

    document.getElementById("backBtn").addEventListener('click', backToCars);

    await updateInfo();
});

function backToCars() {
    window.location.href = '/';
}

async function updateInfo() {
    const result = await getOneCar(carId);

    const car = result[0];

    document.getElementById('carName').textContent = car.name;
    document.getElementById('carPrice').innerHTML = `Price: <b>$${car.price}</b>`;
    document.getElementById('carDescription').textContent = car.description;
    document.getElementById('carImg').src = car.img;

    document.getElementById('car-name').value = car.name;
    document.getElementById('car-price').value = car.price;
    document.getElementById('car-description').value = car.description;
    document.getElementById('car-img').value = car.img;
}

async function updateThisCar() {
    const carName = document.getElementById('car-name').value;
    const carPrice = document.getElementById('car-price').value;
    const carDescription = document.getElementById('car-description').value;
    const carImg = document.getElementById('car-img').value;

    await updateCar(carId, carName, carDescription, carPrice, carImg);

    await updateInfo();
}