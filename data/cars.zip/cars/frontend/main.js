import { getAllCars, addCar, deleteCar } from "../requests/car.requests.js";
import { createItem } from "./components/item.js";

let carsContainer = document.getElementById('carList');

async function generateElements() {
    const cars = await getAllCars();

    carsContainer.innerHTML = '';
    
    cars.forEach((x) => {
        const {item, editBtn, deleteBtn} = createItem(x.name, x.description, x.price, x.img);

        carsContainer.append(item);

        editBtn.addEventListener('click', ()=>{
            window.location.href = `/car/${x.id}`;
        });

        deleteBtn.addEventListener('click', ()=> {
            if (confirm('Are you sure you want to delete this car?')) {
                deleteCar(x.id);

                generateElements();
                return;
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', async (e) => {
    await generateElements();

    const form = document.getElementById('carForm');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const carName = document.getElementById('inputName').value;
        const carDescription = document.getElementById('inputDescription').value;
        const carPrice = document.getElementById('inputPrice').value;
        const carImg = document.getElementById('inputImg').value;

        await addCar(carName, carDescription, carPrice, carImg);
        generateElements();
    });
});