CREATE TABLE IF NOT EXISTS cars(
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    description VARCHAR(255),
    price INTEGER,
    img VARCHAR(255)
);