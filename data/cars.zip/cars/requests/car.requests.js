async function getAllCars() {
    const response = await fetch('/api/car', {
        method: 'GET'
    });

    const result = await response.json();
    return result;
}

async function getOneCar(id) {
    const response = await fetch(`/api/car/` + id, {
        method: 'GET'
    });

    const result = await response.json();
    return result;
}

async function addCar(name, description, price, img) {
    await fetch('/api/car', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            description,
            price,
            img
        })
    });
}

async function deleteCar(id) {
    await fetch('/api/car/' + id, {
        method: 'DELETE'
    });
}

async function updateCar(id, name, description, price, img) {
    await fetch('/api/car/', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id,
            name,
            description,
            price,
            img
        })
    });
}

export {getAllCars, getOneCar, deleteCar, updateCar, addCar}