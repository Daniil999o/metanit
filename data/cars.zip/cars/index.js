const express = require('express');
const PORT = process.env.PORT || 8080;

const carRouter = require('./routes/car.routes.js');

const app = express();

app.use(express.json());
app.use(carRouter);

app.use(express.static(__dirname));

app.get('/', (req, res)=>{
    res.sendFile(__dirname + '/static/index.html');
});

app.get('/car/:id', (req, res)=>{
    res.sendFile(__dirname + '/static/public/singlecar.html');
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});